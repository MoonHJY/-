#ifndef _DMA_H
#define _DMA_H
#include "stm32f10x.h"



void ADC_DMA_config(void);


#endif 

