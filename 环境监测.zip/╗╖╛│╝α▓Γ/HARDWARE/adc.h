#ifndef _ADC_H_
#define _ADC_H_

#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "dma.h"
extern	u16 ADC_ConValue;//ADC�ɼ�����ֵ	

//void ADC_Pin_Init(void);
u16 ADC_Trans(void);
void ADCx_Init(void);
#endif
