
#ifndef __oledfont_H
#define	__oledfont_H

#include "stm32f10x.h"

extern  unsigned char codeBMP2[];
extern  unsigned char codeF8X16[];
extern  unsigned char codeF16x16[];
extern  unsigned char codeBMP1[];

#endif /* __DHT11_H */


