
#ifndef __oled_H
#define	__oled_H

#include "stm32f10x.h"
#include "delay.h"
#include "oledfont.h"

#define  OLED_CS_0   GPIO_ResetBits(GPIOB, GPIO_Pin_9) 
#define  OLED_CS_1   GPIO_SetBits(GPIOB, GPIO_Pin_9) 
#define  OLED_DC_0   GPIO_ResetBits(GPIOB, GPIO_Pin_8) 
#define  OLED_DC_1   GPIO_SetBits(GPIOB, GPIO_Pin_8) 
#define  OLED_RES_0   GPIO_ResetBits(GPIOB, GPIO_Pin_7) 
#define  OLED_RES_1   GPIO_SetBits(GPIOB, GPIO_Pin_7) 
#define  OLED_MOSI_0   GPIO_ResetBits(GPIOB, GPIO_Pin_6) //D1
#define  OLED_MOSI_1   GPIO_SetBits(GPIOB, GPIO_Pin_6)
#define  OLED_SCK_0   GPIO_ResetBits(GPIOB, GPIO_Pin_5) //D0
#define  OLED_SCK_1   GPIO_SetBits(GPIOB, GPIO_Pin_5) 


#define OLED_WR_CMD     0
#define OLED_WR_DAT     1

#define SIZE 16

#define XLevelL        0x00
#define XLevelH        0x10
#define XLevel         ((XLevelH&0x0F)*16+XLevelL)
#define Max_Column     128
#define Max_Row        64
#define Brightness     0xCF 
#define X_WIDTH        128
#define Y_WIDTH        64



//m^n����
u32 oled_pow(u8 m,u8 n);
	
//��ʾ2������
//x,y :�������	 
//len :���ֵ�λ��
//size:�����С
//mode:ģʽ	0,���ģʽ;1,����ģʽ
//num:��ֵ(0~4294967295);	 		  
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size);

//��ʾһ���ַ��Ŵ�
void OLED_ShowString(u8 x,u8 y,u8 *chr);




void oled_init(void);//�ܵĳ�ʼ��
  void SPI_GPIO_Init(void);
  void OLED_Init(void);
 void OLED_Fill(uint8_t bmp_dat);
  void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr);
  void OLED_Set_Pos(uint8_t x, uint8_t y);
 void LCD_P8x16Str(uint8_t x, uint8_t y,uint8_t ch[]);
  void LCD_P16x16Ch(uint8_t x, uint8_t y, uint8_t N);
  void OLED_DrawBMP(uint8_t x0, uint8_t y0,uint8_t x1, uint8_t y1,const uint8_t BMP[]);





#endif /* __DHT11_H */


